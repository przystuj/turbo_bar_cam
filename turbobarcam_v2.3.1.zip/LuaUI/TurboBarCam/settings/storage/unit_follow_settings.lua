return {
  ["armcom"] = {
    ["attack_state_cooldown"] = 4,
    ["forced_weapon_number"] = 1,
  },
  ["armsam"] = {
    ["attack_state_cooldown"] = 4,
    ["forced_weapon_number"] = 2,
  },
  ["armthor"] = {
    ["attack_state_cooldown"] = 2,
    ["forced_weapon_number"] = 1,
  },
  ["corban"] = {
    ["attack_state_cooldown"] = 4,
  },
  ["corcom"] = {
    ["attack_state_cooldown"] = 4,
    ["forced_weapon_number"] = 1,
  },
  ["corhurc"] = {
    ["attack_state_cooldown"] = 3,
    ["forced_weapon_number"] = 1,
  },
  ["corjugg"] = {
    ["attack_state_cooldown"] = 4,
    ["forced_weapon_number"] = 1,
  },
  ["corkarg"] = {
    ["attack_state_cooldown"] = 2,
  },
  ["corkorg"] = {
    ["attack_state_cooldown"] = 4,
    ["forced_weapon_number"] = 2,
  },
  ["cormist"] = {
    ["attack_state_cooldown"] = 4,
    ["forced_weapon_number"] = 2,
  },
  ["corthud"] = {
    ["attack_state_cooldown"] = 2,
  },
}