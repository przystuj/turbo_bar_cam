---@type ModuleManager
local ModuleManager = WG.TurboBarCam.ModuleManager
local STATE = ModuleManager.STATE(function(m) STATE = m end)
local CONFIG = ModuleManager.CONFIG(function(m) CONFIG = m end)
local CONSTANTS = ModuleManager.CONSTANTS(function(m) CONSTANTS = m end)
local Log = ModuleManager.Log(function(m) Log = m end, "UnitFollowUtils")
local Utils = ModuleManager.Utils(function(m) Utils = m end)
local ModeManager = ModuleManager.ModeManager(function(m) ModeManager = m end)
local UnitFollowCombatMode = ModuleManager.UnitFollowCombatMode(function(m) UnitFollowCombatMode = m end)
local UnitFollowTargeting = ModuleManager.UnitFollowTargeting(function(m) UnitFollowTargeting = m end)
local UnitFollowPersistence = ModuleManager.UnitFollowPersistence(function(m) UnitFollowPersistence = m end)
local ParamUtils = ModuleManager.ParamUtils(function(m) ParamUtils = m end)
local WorldUtils = ModuleManager.WorldUtils(function(m) WorldUtils = m end)
local SettingsManager = ModuleManager.SettingsManager(function(m) SettingsManager = m end)

---@class UnitFollowUtils
local UnitFollowUtils = {}

--- Checks if unit_follow camera should be updated
---@return boolean shouldUpdate Whether unit_follow camera should be updated
function UnitFollowUtils.shouldUpdateCamera()
    if STATE.active.mode.name ~= 'unit_follow' or not STATE.active.mode.unitID then
        return false
    end

    -- Check if unit still exists
    if not Spring.ValidUnitID(STATE.active.mode.unitID) then
        local lastSelection = STATE.core.selection
        if lastSelection.lastUnitID == STATE.active.mode.unitID and lastSelection.lastUpdateTime then
            local elapsed = Spring.DiffTimers(Spring.GetTimer(), lastSelection.lastUpdateTime)
            if elapsed < 5 then
                return true
            end
        end

        ModeManager.disableMode()
        return false
    end

    return true
end

--- Calculate the height if it's not set
function UnitFollowUtils.ensureHeightIsSet()
    -- Set DEFAULT mode height if not set
    if not CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.DEFAULT.HEIGHT then
        local unitHeight = math.max(WorldUtils.getUnitHeight(STATE.active.mode.unitID), 100) + 30
        CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.DEFAULT.HEIGHT = unitHeight
    end

    -- Ensure COMBAT mode height is set (though it should have a default)
    if not CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.COMBAT.HEIGHT then
        CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.COMBAT.HEIGHT = CONFIG.CAMERA_MODES.UNIT_FOLLOW.DEFAULT_OFFSETS.COMBAT.HEIGHT
    end

    -- Ensure WEAPON mode height is set (though it should have a default)
    if not CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.WEAPON.HEIGHT then
        CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.WEAPON.HEIGHT = CONFIG.CAMERA_MODES.UNIT_FOLLOW.DEFAULT_OFFSETS.WEAPON.HEIGHT
    end
end

--- Gets appropriate offsets based on current mode
---@return table offsets The offsets to apply
function UnitFollowUtils.getAppropriateOffsets()
    -- In combat mode - check if actively attacking
    if STATE.active.mode.unit_follow.combatModeEnabled then
        if STATE.active.mode.unit_follow.isAttacking then
            -- Weapon offsets - when actively targeting something
            return CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.WEAPON
        else
            -- Combat offsets - when in combat mode but not targeting
            return CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.COMBAT
        end
    else
        -- Peace mode - normal offsets
        return CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.DEFAULT
    end
end

--- Creates a basic camera state object with the specified position and direction
---@param position table Camera position {x, y, z}
---@param direction table Camera direction {dx, dy, dz, rx, ry, rz}
---@return table cameraState Complete camera state object
function UnitFollowUtils.createCameraState(position, direction)
    return {
        -- Position
        px = position.x,
        py = position.y,
        pz = position.z,

        -- Direction
        dx = direction.dx,
        dy = direction.dy,
        dz = direction.dz,

        -- Rotation
        rx = direction.rx,
        ry = direction.ry,
        rz = direction.rz
    }
end

--- Creates direction state based on unit's hull direction
--- @param unitID number Unit ID
--- @param offsets table Offsets to use
--- @return table directionState Camera direction state
function UnitFollowUtils.createHullDirectionState(unitID, offsets)
    local dx, dy, dz = Spring.GetUnitDirection(unitID)

    local horizontalLength = math.sqrt(dx * dx + dz * dz)
    local unitPitch = -math.atan2(dy, horizontalLength)

    local targetRx = 1.8 + unitPitch

    local targetRy = -(Spring.GetUnitHeading(unitID, true) + math.pi) + offsets.ROTATION

    return { rx = targetRx, ry = targetRy, }, CONSTANTS.TARGET_TYPE.EULER
end

--- Creates direction state when actively firing at a target
--- @param unitID number Unit ID
--- @param targetPos table Target position
--- @param weaponNum number|nil Weapon number
--- @param rotFactor number Rotation smoothing factor
--- @return table|nil directionState Camera direction state or nil if it fails
function UnitFollowUtils.createTargetingDirectionState(unitID, targetPos, weaponNum)
    if not targetPos or not weaponNum then
        return nil
    end

    local attachToWeapon = CONFIG.CAMERA_MODES.UNIT_FOLLOW.ATTACH_TO_WEAPON
    local originX, originY, originZ

    if attachToWeapon then
        local posX, posY, posZ, destX = Spring.GetUnitWeaponVectors(unitID, weaponNum)
        if not posX or not destX then
            return nil
        end
        originX, originY, originZ = posX, posY, posZ
    else
        local hullX, hullY, hullZ = Spring.GetUnitPosition(unitID)
        if not hullX then
            return nil
        end

        originX = hullX
        originY = hullY
        originZ = hullZ
    end

    local weaponPos
    if attachToWeapon then
        weaponPos = { x = originX, y = originY, z = originZ }
    end

    -- Apply target smoothing here - this is the key addition!
    -- Process the target through all smoothing systems (cloud targeting, rotation constraints)
    local processedTarget = UnitFollowTargeting.processTarget(targetPos, STATE.active.mode.unit_follow.lastTargetUnitID)

    if processedTarget then
        targetPos = processedTarget
    end

    -- Calculate direction to target (not weapon direction)
    local dx = targetPos.x - originX
    local dy = targetPos.y - originY
    local dz = targetPos.z - originZ
    local magnitude = math.sqrt(dx * dx + dy * dy + dz * dz)

    if magnitude < 0.001 then
        return nil
    end

    -- Normalize direction vector
    dx, dy, dz = dx / magnitude, dy / magnitude, dz / magnitude

    -- Store position and direction for other functions
    STATE.active.mode.unit_follow.weaponPos = weaponPos
    STATE.active.mode.unit_follow.weaponDir = { dx, dy, dz }
    STATE.active.mode.unit_follow.activeWeaponNum = weaponNum

    return targetPos
end

--- Handles normal unit_follow mode camera orientation
--- @param unitID number Unit ID
--- @return table directionState Camera direction and rotation state
function UnitFollowUtils.handleNormalFollowMode(unitID)
    -- Check if combat mode is enabled
    if STATE.active.mode.unit_follow.combatModeEnabled then
        -- Check if the unit is actively targeting something
        local targetPos, firingWeaponNum, isNewTarget = UnitFollowCombatMode.getCurrentAttackTarget(unitID)
        if isNewTarget and not STATE.active.mode.unit_follow.isTargetSwitchTransition then
            UnitFollowUtils.handleNewTarget()
        end

        if STATE.active.mode.unit_follow.isAttacking then
            -- Try to create direction state based on targeting data
            local targetingState = UnitFollowUtils.createTargetingDirectionState(unitID, targetPos, firingWeaponNum or STATE.active.mode.unit_follow.activeWeaponNum)

            if targetingState then
                -- Successfully created targeting state
                return targetingState, CONSTANTS.TARGET_TYPE.POINT
            end
        end

        -- If we get here, we're in combat mode but not attacking (or couldn't create targeting state)
        -- Use combat offset mode
        return UnitFollowUtils.createHullDirectionState(unitID, CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.COMBAT)
    else
        -- Normal mode - always ensure isAttacking is false
        STATE.active.mode.unit_follow.isAttacking = false
        return UnitFollowUtils.createHullDirectionState(unitID, CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.DEFAULT)
    end
end

function UnitFollowUtils.handleNewTarget()
    local trackedUnitID = STATE.active.mode.unitID
    if not trackedUnitID or not Spring.ValidUnitID(trackedUnitID) then
        return
    end

    -- Initialize state fields if needed
    if not STATE.active.mode.unit_follow.previousTargetPos and STATE.active.mode.unit_follow.lastTargetPos then
        STATE.active.mode.unit_follow.previousTargetPos = {
            x = STATE.active.mode.unit_follow.lastTargetPos.x,
            y = STATE.active.mode.unit_follow.lastTargetPos.y,
            z = STATE.active.mode.unit_follow.lastTargetPos.z
        }
    end

    if not STATE.active.mode.unit_follow.lastTargetSwitchTime then
        STATE.active.mode.unit_follow.lastTargetSwitchTime = Spring.GetTimer()
    end

    -- Check for target suitability
    local newTargetPos = STATE.active.mode.unit_follow.lastTargetPos
    local previousTargetPos = STATE.active.mode.unit_follow.previousTargetPos

    -- Skip if we don't have proper target data
    if not newTargetPos then
        return
    end

    -- First acquisition just store it
    if not previousTargetPos then
        if trackedUnitID then
            local ux, uy, uz = Spring.GetUnitPosition(trackedUnitID)
            STATE.active.mode.unit_follow.previousTargetPos = { x = ux, y = uy, z = uz }
            previousTargetPos = STATE.active.mode.unit_follow.previousTargetPos
        else
            STATE.active.mode.unit_follow.previousTargetPos = {
                x = newTargetPos.x,
                y = newTargetPos.y,
                z = newTargetPos.z
            }
            return
        end
    end

    -- Get current time
    local currentTime = Spring.GetTimer()

    -- Rate limiting criteria
    local timeSinceLastTransition = Spring.DiffTimers(currentTime, STATE.active.mode.unit_follow.lastTargetSwitchTime)
    local minTimeBetweenTransitions = STATE.active.mode.unit_follow.isTargetSwitchTransition and 0.5 or 1.0

    -- Enhanced decision criteria:
    local isInTransition = STATE.active.mode.unit_follow.isTargetSwitchTransition
    local isTimeSufficientForNewTransition = timeSinceLastTransition > minTimeBetweenTransitions

    -- Skip transition if:
    -- 1. Already in transition, OR
    -- 2. Distance too small, OR
    -- 3. Last transition was too recent
    if isInTransition or (not isTimeSufficientForNewTransition) then
        -- Just update the previous target position without starting a new transition
        STATE.active.mode.unit_follow.previousTargetPos = {
            x = newTargetPos.x,
            y = newTargetPos.y,
            z = newTargetPos.z
        }
        return
    end

    -- Start transition
    STATE.active.mode.unit_follow.isTargetSwitchTransition = true
    STATE.active.mode.unit_follow.lastTargetSwitchTime = currentTime

    -- Signal rotation constraints to reset
    STATE.active.mode.unit_follow.targeting.rotationConstraint.resetForSwitch = true

    -- Store this target position for future comparisons
    STATE.active.mode.unit_follow.previousTargetPos = {
        x = newTargetPos.x,
        y = newTargetPos.y,
        z = newTargetPos.z
    }
end

--- Clears fixed point tracking
function UnitFollowUtils.clearFixedLookPoint()
    if Utils.isTurboBarCamDisabled() then
        return
    end

    STATE.active.mode.unit_follow.isFixedPointActive = false
    STATE.active.mode.unit_follow.fixedTarget = nil
    STATE.active.mode.unit_follow.inTargetSelectionMode = false
    STATE.active.mode.unit_follow.prevFixedTarget = nil
end

--- Determines appropriate smoothing factors based on current state
---@param smoothType string Type of smoothing ('position', 'rotation')
---@return number smoothingFactor The smoothing factor to use
function UnitFollowUtils.getSmoothingFactor(smoothType)
    -- Determine which mode we're in
    local smoothingMode
    if STATE.active.mode.unit_follow.combatModeEnabled then
        if STATE.active.mode.unit_follow.isAttacking then
            smoothingMode = "WEAPON"
        else
            smoothingMode = "COMBAT"
        end
    else
        smoothingMode = "DEFAULT"
    end

    if STATE.active.mode.unit_follow.unitTransitionStartTime then
        if smoothType == 'position' then
            return CONFIG.CAMERA_MODES.UNIT_FOLLOW.UNIT_TRANSITION_POS_SMOOTHING
        elseif smoothType == 'rotation' then
            return CONFIG.CAMERA_MODES.UNIT_FOLLOW.UNIT_TRANSITION_ROT_SMOOTHING
        end
    end

    -- Get the appropriate smoothing factor based on mode and type
    if smoothType == 'position' then
        return CONFIG.CAMERA_MODES.UNIT_FOLLOW.SMOOTHING[smoothingMode].POSITION_FACTOR
    elseif smoothType == 'rotation' then
        return CONFIG.CAMERA_MODES.UNIT_FOLLOW.SMOOTHING[smoothingMode].ROTATION_FACTOR
    end
end

local function getParamPrefixes()
    return {
        DEFAULT = "DEFAULT.",
        COMBAT = "COMBAT.",
        WEAPON = "WEAPON."
    }
end

--- Update adjustParams to handle the new offset structure
function UnitFollowUtils.adjustParams(params)
    if Utils.isTurboBarCamDisabled() then
        return
    end
    if Utils.isModeDisabled("unit_follow") then
        return
    end

    -- Make sure we have a unit to track
    if not STATE.active.mode.unitID then
        Log:trace("No unit being tracked")
        return
    end

    -- Handle reset directly
    if params == "reset" then
        UnitFollowUtils.resetOffsets()
        SettingsManager.saveModeSettings("unit_follow", STATE.active.mode.unitID)
        return
    end

    -- Determine current submode
    local currentSubMode
    if STATE.active.mode.unit_follow.combatModeEnabled then
        if STATE.active.mode.unit_follow.isAttacking then
            currentSubMode = "WEAPON"
        else
            currentSubMode = "COMBAT"
        end
    else
        currentSubMode = "DEFAULT"
    end

    Log:trace("Adjusting unit_follow parameters for submode: " .. currentSubMode)

    local isTemporary = ParamUtils.adjustParams(params, "UNIT_FOLLOW", function()
        UnitFollowUtils.resetOffsets()
    end, currentSubMode, getParamPrefixes)

    SettingsManager.saveModeSettings("unit_follow", STATE.active.mode.unitID, isTemporary)
end

--- Resets camera offsets to default values
function UnitFollowUtils.resetOffsets()
    local function reset(mode)
        TableUtils.patchTable(CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS[mode], CONFIG.CAMERA_MODES.UNIT_FOLLOW.DEFAULT_OFFSETS[mode])
    end

    reset("DEFAULT")
    reset("COMBAT")
    reset("WEAPON")

    CONFIG.CAMERA_MODES.UNIT_FOLLOW.OFFSETS.ATTACK_STATE_COOLDOWN = CONFIG.CAMERA_MODES.UNIT_FOLLOW.DEFAULT_OFFSETS.ATTACK_STATE_COOLDOWN

    UnitFollowUtils.ensureHeightIsSet()
    Log:trace("Restored unit_follow camera settings to defaults")
    return true
end

local camPosScratch = { x = 0, y = 0, z = 0 }
local rightVecScratch = { 0, 0, 0 }

--- Applies unit_follow camera offsets to unit position, handling target switch transitions
---@param x number Unit x position
---@param y number Unit y position
---@param z number Unit z position
---@param front table Unit Front vector
---@param up table Unit Up vector
---@param right table Unit Right vector
---@return table camPos Final Camera position with offsets applied
function UnitFollowUtils.applyOffsets(x, y, z, front, up, right)
    UnitFollowUtils.ensureHeightIsSet()
    local offsets = UnitFollowUtils.getAppropriateOffsets()

    -- Determine which vectors to use based on state
    local frontVec, upVec, rightVec

    if STATE.active.mode.unit_follow.isAttacking and STATE.active.mode.unit_follow.weaponDir then
        -- Use weapon position when attacking if available
        if STATE.active.mode.unit_follow.weaponPos then
            x, y, z = STATE.active.mode.unit_follow.weaponPos.x, STATE.active.mode.unit_follow.weaponPos.y, STATE.active.mode.unit_follow.weaponPos.z
        end
        -- Use weapon direction when attacking
        frontVec = STATE.active.mode.unit_follow.weaponDir
        upVec = up
        -- Calculate right vector from front and up vectors
        rightVec = rightVecScratch
        rightVec[1] = frontVec[2] * upVec[3] - frontVec[3] * upVec[2]
        rightVec[2] = frontVec[3] * upVec[1] - frontVec[1] * upVec[3]
        rightVec[3] = frontVec[1] * upVec[2] - frontVec[2] * upVec[1]
    else
        -- Use standard vectors otherwise
        frontVec = front
        upVec = up
        rightVec = right
    end

    -- Extract components from the vector tables
    local frontX, frontY, frontZ = frontVec[1], frontVec[2], frontVec[3]
    local upX, upY, upZ = upVec[1], upVec[2], upVec[3]
    local rightX, rightY, rightZ = rightVec[1], rightVec[2], rightVec[3]

    -- Apply offsets directly to position components
    if offsets.HEIGHT ~= 0 then
        x = x + upX * offsets.HEIGHT
        y = y + upY * offsets.HEIGHT
        z = z + upZ * offsets.HEIGHT
    end

    if offsets.FORWARD ~= 0 then
        x = x + frontX * offsets.FORWARD
        y = y + frontY * offsets.FORWARD
        z = z + frontZ * offsets.FORWARD
    end

    if offsets.SIDE ~= 0 then
        x = x + rightX * offsets.SIDE
        y = y + rightY * offsets.SIDE
        z = z + rightZ * offsets.SIDE
    end

    -- Calculate the target world position (with offsets applied)
    camPosScratch.x, camPosScratch.y, camPosScratch.z = x, y, z

    -- Apply minimum height constraint to target position
    local targetCamPosWorld = UnitFollowUtils.enforceMinimumHeight(camPosScratch, STATE.active.mode.unitID)

    local finalCamPosWorld = targetCamPosWorld

    -- Apply stabilization
    local stabilizedPos = UnitFollowUtils.applyStabilization(targetCamPosWorld)
    if stabilizedPos then
        finalCamPosWorld = stabilizedPos
    end

    -- This ensures the air adjustment respects the stabilized camera state
    if STATE.active.mode.unit_follow.isAttacking and STATE.active.mode.unit_follow.lastTargetPos then
        finalCamPosWorld = UnitFollowTargeting.handleAirTargetRepositioning(
            finalCamPosWorld,
            STATE.active.mode.unit_follow.lastTargetPos,
            camPosScratch -- use camPosScratch for reference or something similar? Original unitPos was used but it was {x,y,z}
        )
    end

    return finalCamPosWorld
end

-- This follows the guideline to split large conditionals into functions
function UnitFollowUtils.applyStabilization(targetCamPosWorld)
    -- Get targeting information from smoothing system
    local targetState = STATE.active.mode.unit_follow.targeting

    -- Only apply stabilization during active targeting with high target switching activity
    if not STATE.active.mode.unit_follow.isAttacking or not targetState or
            not targetState.activityLevel or targetState.activityLevel <= 0.5 then
        -- Reset stabilization when not in a high-activity targeting situation
        STATE.active.mode.unit_follow.stableCamPos = nil
        return nil
    end

    -- Initialize stable camera position history if needed
    if not STATE.active.mode.unit_follow.stableCamPos then
        STATE.active.mode.unit_follow.stableCamPos = targetCamPosWorld
        STATE.active.mode.unit_follow.cameraStabilityFactor = 0.05 -- Default slow response
    end

    -- Calculate stabilization factors
    local factor = UnitFollowUtils.calculateStabilityFactor(targetState)

    -- Apply very gradual interpolation towards the target position
    local stableCamPos = STATE.active.mode.unit_follow.stableCamPos

    local smoothedCamPos = {
        x = stableCamPos.x + (targetCamPosWorld.x - stableCamPos.x) * factor,
        y = stableCamPos.y + (targetCamPosWorld.y - stableCamPos.y) * factor,
        z = stableCamPos.z + (targetCamPosWorld.z - stableCamPos.z) * factor
    }

    -- Update stable camera position for next frame
    STATE.active.mode.unit_follow.stableCamPos = smoothedCamPos

    return smoothedCamPos
end

-- Calculate stability factor based on activity level
-- Following the guideline to avoid code duplication
function UnitFollowUtils.calculateStabilityFactor(targetState)
    local stabilityBase = CONFIG.CAMERA_MODES.UNIT_FOLLOW.STABILIZATION.BASE_FACTOR
    local maxStability = CONFIG.CAMERA_MODES.UNIT_FOLLOW.STABILIZATION.MAX_FACTOR

    -- Scale stability factor inversely with activity level
    local activityScaling = math.min(targetState.activityLevel * 1.5, 1.0)
    local factor = stabilityBase - (activityScaling * (stabilityBase - maxStability))

    -- Add rapid switch counter to increase stabilization for very rapid switching
    if targetState.targetSwitchCount > 100 then
        -- Further decrease factor for extremely high switching rates
        factor = factor * 0.8
    end

    -- Store the factor for reference
    STATE.active.mode.unit_follow.cameraStabilityFactor = factor

    return factor
end

--- Ensures camera doesn't go below minimum height
--- @param position table Camera position {x, y, z}
--- @param unitID number The unit ID
--- @return table adjustedPos Position with height constraint applied
function UnitFollowUtils.enforceMinimumHeight(position, unitID)
    if not position then
        return position
    end

    local minHeight = UnitFollowUtils.getMinimumCameraHeight(unitID)
    local x, y, z = position.x, position.y, position.z

    -- Get ground height at the position
    local groundHeight = Spring.GetGroundHeight(x, z)

    -- Ensure camera is at least minHeight above ground
    if y < (groundHeight + minHeight) then
        y = groundHeight + minHeight
    end

    return { x = x, y = y, z = z }
end

--- Gets minimum height for camera position
--- @param unitID number The unit ID
--- @return number minHeight Minimum height above ground
function UnitFollowUtils.getMinimumCameraHeight(unitID)
    if not Spring.ValidUnitID(unitID) then
        return 50 -- Default fallback
    end

    -- Get unit height
    local unitDefID = Spring.GetUnitDefID(unitID)
    local unitDef = UnitDefs[unitDefID]
    if not unitDef then
        return 50
    end

    -- Use half of the unit height as minimum (or a fixed value if that's too small)
    local baseUnitHeight = unitDef.height or 0
    return math.max(baseUnitHeight * 0.5, 50) -- At least half unit height or 50 units
end

return UnitFollowUtils
