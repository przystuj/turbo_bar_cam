return {
  ["orbit"] = {
    ["DISTANCE"] = 540,
    ["HEIGHT"] = 320,
    ["SPEED"] = 0.06000019,
  },
}