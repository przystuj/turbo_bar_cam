return {
    metadata = {
        replayName = "2026-02-21_22-53-16-851_All That Glitters v2.2.3_2025.06.19",
        version = 1,
    },
    steps = {

        -- STEP #01 Init
        {
            frame = 0,
            label = "Init",
            commands = {
                "skip f7290",
            }
        },

        -- STEP #02 Thug
        {
            frame = 7290,
            label = "Thug",
            commands = {
                "turbobarcam_smoothing reset",
                "turbobarcam_toggle_unit_follow_camera 8522 combat",
                "turbobarcam_script_select_unit_team 8522",
            }
        },

        -- STEP #03 Thug
        {
            frame = 7951,
            label = "Thug",
            commands = {
                "turbobarcam_smoothing reset",
                "turbobarcam_toggle_unit_follow_camera 25108 combat",
                "turbobarcam_script_select_unit_team 25108",
            }
        },

        -- STEP #04 Thug
        {
            frame = 10472,
            label = "Thug",
            commands = {
                "turbobarcam_smoothing reset",
                "turbobarcam_toggle_unit_follow_camera 24559 combat",
                "turbobarcam_script_select_unit_team 24559",
            }
        },

        -- STEP #05 Lasher
        {
            frame = 11391,
            label = "Lasher",
            commands = {
                "turbobarcam_smoothing reset",
                "turbobarcam_toggle_unit_follow_camera 9900 combat",
                "turbobarcam_script_select_unit_team 9900",
            }
        },

        -- STEP #06 Lasher
        {
            frame = 12682,
            label = "Lasher",
            commands = {
                "turbobarcam_smoothing reset",
                "turbobarcam_toggle_unit_follow_camera 13941 combat",
                "turbobarcam_script_select_unit_team 13941",
            }
        },

        -- STEP #07 Pawn
        {
            frame = 13313,
            label = "Pawn",
            commands = {
                "turbobarcam_smoothing reset",
                "turbobarcam_toggle_unit_follow_camera 21207 combat",
                "turbobarcam_script_select_unit_team 21207",
            }
        },

        -- STEP #08 Pawn
        {
            frame = 14514,
            label = "Pawn",
            commands = {
                "turbobarcam_smoothing reset",
                "turbobarcam_toggle_unit_follow_camera 21805 combat",
                "turbobarcam_script_select_unit_team 21805",
            }
        },

        -- STEP #09 END
        {
            frame = 15427,
            label = "END",
            commands = {
            }
        },
    }
}
