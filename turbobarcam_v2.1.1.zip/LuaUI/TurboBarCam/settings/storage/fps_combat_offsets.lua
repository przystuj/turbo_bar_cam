return {
  ["armepoch"] = {
    ["FORWARD"] = -75,
    ["HEIGHT"] = 35,
    ["ROTATION"] = 0,
    ["SIDE"] = 0,
  },
}