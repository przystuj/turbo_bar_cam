return {
  ["armepoch"] = {
    ["FORWARD"] = -30,
    ["HEIGHT"] = 75,
    ["ROTATION"] = 1.50000036,
    ["SIDE"] = -235,
  },
}