return {
  ["armbrtha"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armck"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armcom"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armfboy"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 120,
      ["LOOK_AHEAD"] = 0,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armliche"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.5,
      ["INITIAL_BRAKING"] = 8,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 460,
      ["HEIGHT"] = -195,
      ["LOOK_AHEAD"] = 0,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = -160,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armmar"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armmerl"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 440,
      ["HEIGHT"] = 245,
      ["LOOK_AHEAD"] = 40,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 500,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armpnix"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 2.0999999,
      ["INITIAL_BRAKING"] = 2.0999999,
      ["PATH_ADHERENCE"] = 0.2,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 240,
      ["HEIGHT"] = 25,
      ["LOOK_AHEAD"] = 680,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armrock"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armsam"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armsilo"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 1220,
      ["HEIGHT"] = 990,
      ["LOOK_AHEAD"] = 480,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armthund"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 2,
      ["INITIAL_BRAKING"] = 8,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 420,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 0,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armvang"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["PATH_ADHERENCE"] = 0.70000005,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 140,
      ["HEIGHT"] = 90,
      ["LOOK_AHEAD"] = 0,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["armvulc"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.0999999,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 500,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corcat"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 105,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corcom"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corhurc"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 380,
      ["HEIGHT"] = 10,
      ["LOOK_AHEAD"] = 0,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 60,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corint"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 3.09999895,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.20000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corkorg"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corshad"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corshiva"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
  ["corsilo"] = {
    ["DECELERATION_PROFILE"] = {
      ["DURATION"] = 1.70000005,
      ["INITIAL_BRAKING"] = 8,
      ["MIN_INITIAL_ROT_VELOCITY"] = 0,
      ["PATH_ADHERENCE"] = 0.60000002,
    },
    ["FOLLOW"] = {
      ["DISTANCE"] = 300,
      ["HEIGHT"] = 100,
      ["LOOK_AHEAD"] = 200,
    },
    ["STATIC"] = {
      ["LOOK_AHEAD"] = 0,
      ["OFFSET_HEIGHT"] = 0,
      ["OFFSET_SIDE"] = 0,
    },
  },
}