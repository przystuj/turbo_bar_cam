return {
  ["orbit"] = {
    ["DISTANCE"] = 100,
    ["HEIGHT"] = 1160,
    ["SPEED"] = -0.0000002,
  },
}