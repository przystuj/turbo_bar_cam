function widget:GetInfo()
    return {
        name = "Turret Direction Debugger",
        desc = "Prints turret rotation data for selected unit",
        author = "Claude",
        date = "April 2025",
        license = "Same as BAR",
        layer = 0,
        enabled = true
    }
end
-- Spring API functions
local spGetSelectedUnits = Spring.GetSelectedUnits
local spGetUnitDefID = Spring.GetUnitDefID
local spValidUnitID = Spring.ValidUnitID
local spEcho = Spring.Echo
local spGetTimer = Spring.GetTimer
local spDiffTimers = Spring.DiffTimers
local spGetUnitWeaponState = Spring.GetUnitWeaponState
local spGetUnitPosition = Spring.GetUnitPosition
local spGetUnitWeaponVectors = Spring.GetUnitWeaponVectors
local spGetUnitPiecePosDir = Spring.GetUnitPiecePosDir
local spGetUnitPieceMap = Spring.GetUnitPieceMap

-- GL drawing functions
local glPushMatrix = gl.PushMatrix
local glPopMatrix = gl.PopMatrix
local glColor = gl.Color
local glLineWidth = gl.LineWidth
local glBeginEnd = gl.BeginEnd
local glVertex = gl.Vertex
local glTranslate = gl.Translate
local GL_LINES = GL.LINES

-- Configuration
local UPDATE_INTERVAL = 0.5  -- Update every half second
local LINE_LENGTH = 50       -- How long to draw the direction lines
local LINE_WIDTH = 2         -- Line width for drawing
local SHOW_CONSOLE_INFO = true  -- Whether to print info in console as well

-- Color configuration
local weaponColors = {
    { 1.0, 0.2, 0.2, 1.0 }, -- Red (weapon 0)
    { 0.2, 1.0, 0.2, 1.0 }, -- Green (weapon 1)
    { 0.2, 0.2, 1.0, 1.0 }, -- Blue (weapon 2)
    { 1.0, 1.0, 0.2, 1.0 }, -- Yellow (weapon 3)
    { 1.0, 0.2, 1.0, 1.0 }, -- Magenta (weapon 4)
    { 0.2, 1.0, 1.0, 1.0 }, -- Cyan (weapon 5)
}

-- Tracking variables
local lastUpdateTime = spGetTimer()
local selectedUnitID = nil
local weaponDirections = {}
local weaponStartPoints = {}
local weaponEndPoints = {}

-- Utility function to normalize a vector
local function normalizeVector(x, y, z)
    local length = math.sqrt(x * x + y * y + z * z)
    if length > 0 then
        return x / length, y / length, z / length
    end
    return x, y, z
end

local function dump(o)
    if type(o) == 'table' then
        local s = '{ '
        for k, v in pairs(o) do
            if type(k) ~= 'number' then
                k = '"' .. k .. '"'
            end
            s = s .. '[' .. k .. '] = ' .. dump(v) .. ','
        end
        return s .. '} '
    else
        return tostring(o)
    end
end

-- Update weapon direction data
function UpdateWeaponData()
    local currentTime = spGetTimer()
    local timeDiff = spDiffTimers(currentTime, lastUpdateTime)

    -- Only update if enough time has passed
    if timeDiff < UPDATE_INTERVAL then
        return
    end

    lastUpdateTime = currentTime

    local selectedUnits = spGetSelectedUnits()

    if #selectedUnits == 0 then
        selectedUnitID = nil
        weaponDirections = {}
        weaponStartPoints = {}
        weaponEndPoints = {}
        return
    end

    -- Use the first selected unit
    local unitID = selectedUnits[1]

    if not spValidUnitID(unitID) then
        return
    end

    -- If unit selection changed
    if unitID ~= selectedUnitID then
        selectedUnitID = unitID
        weaponDirections = {}
        weaponStartPoints = {}
        weaponEndPoints = {}

        if SHOW_CONSOLE_INFO then
            local unitDefID = spGetUnitDefID(unitID)
            local unitDef = UnitDefs[unitDefID]
            spEcho("Selected unit: " .. unitDef.name .. " (ID: " .. unitID .. ")")
            spEcho("Visualizing weapon directions...")
        end
    end

    -- Get unit position
    local ux, uy, uz = spGetUnitPosition(unitID)
    if not ux then
        return
    end

    -- Get unit definition
    local unitDefID = Spring.GetUnitDefID(unitID)
    local unitDef = UnitDefs[unitDefID]

    -- Process each weapon
    for weaponNum, weaponData in pairs(unitDef.weapons) do
        if type(weaponNum) == "number" then
            local weaponDefID = weaponData.weaponDef
            local weaponDef = WeaponDefs[weaponDefID]

            local reloadSpeed = Spring.GetUnitWeaponState(unitID, weaponNum, "reloadSpeed")
            local posX, posY, posZ, destX, destY, destZ = Spring.GetUnitWeaponVectors(unitID, weaponNum)
            --local wepdamages = Spring.GetUnitWeaponDamages(unitID, weaponNum)

            local targetType, isUserTarget, target = Spring.GetUnitWeaponTarget(unitID, weaponNum)

            Spring.Echo(dump({targetType, isUserTarget, target, reloadSpeed}))
        end
    end

end

-- Main update function
function widget:Update()
    UpdateWeaponData()
end

-- Drawing function
function widget:DrawWorld()
    if not selectedUnitID or not spValidUnitID(selectedUnitID) then
        return
    end

    glLineWidth(LINE_WIDTH)

    for weaponNum, direction in pairs(weaponDirections) do
        -- Skip if we don't have start/end points
        if weaponStartPoints[weaponNum] and weaponEndPoints[weaponNum] then
            -- Get points
            local startPt = weaponStartPoints[weaponNum]
            local endPt = weaponEndPoints[weaponNum]

            -- Select color based on weapon number
            local colorIdx = (weaponNum % #weaponColors) + 1
            glColor(weaponColors[colorIdx][1], weaponColors[colorIdx][2],
                    weaponColors[colorIdx][3], weaponColors[colorIdx][4])

            -- Draw line
            glBeginEnd(GL_LINES, function()
                glVertex(startPt[1], startPt[2], startPt[3])
                glVertex(endPt[1], endPt[2], endPt[3])
            end)
        end
    end

    -- Reset GL state
    glLineWidth(1)
    glColor(1, 1, 1, 1)
end

-- Add key binding to toggle console info
function widget:KeyPress(key, mods, isRepeat)
    if key == 73 and mods.ctrl then
        -- Ctrl+I
        SHOW_CONSOLE_INFO = not SHOW_CONSOLE_INFO
        spEcho("Console info " .. (SHOW_CONSOLE_INFO and "enabled" or "disabled"))
        return true
    end
    return false
end