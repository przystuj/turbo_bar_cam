return {
  ["armcom"] = {
    FORWARD = -200,
    HEIGHT = 50,
    SIDE = -85,
    ROTATION = 0
  },
  ["corcom"] = {
    FORWARD = -390,
    HEIGHT = 210,
    SIDE = 260,
    ROTATION = 0
  },
}