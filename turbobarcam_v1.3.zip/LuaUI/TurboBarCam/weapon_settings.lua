return {
  ["armcom"] = {
    FORWARD = -200,
    HEIGHT = 50,
    SIDE = 0,
    ROTATION = 0
  },
  ["corcom"] = {
    FORWARD = 0,
    HEIGHT = 0,
    SIDE = 80,
    ROTATION = 0
  },
}