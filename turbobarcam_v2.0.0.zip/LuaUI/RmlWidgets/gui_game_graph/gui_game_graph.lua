if not RmlUi then
    return
end

local widget = widget ---@type Widget

function widget:GetInfo()
    return {
		name      = "GameGraph",
		desc      = "Displays stats from throughout the game as a graph.",
		author    = "Puppyguard",
		version   = "",
		date      = "July 2025",
		license   = "GNU GPL, v2 or later",
        layer     = -99990,
        enabled   = true
    }
end

local document
local dm -- Data model
local graph_holder
local graph_absolute_y
local graphHeight, graphWidth
local graphMarginY = 2
local graphMarginX = 0
local lastSelectedGraphKey = "metalUsed"

local main_model_name = "gui_game_graph_model"

local isVisible = false
local graphIsHovered = false


local statButtons = {}

-- Contains tables of vertices + colors.
-- Example Value: 
--[[
graphs={
	{
		{v={5,15,0.0},c={1,1,1,1}},
		{v={25,150,0.0},c={1,1,1,1}}
	},
	{
		{v={5,15,0.0},c={1,1,1,1}},
		{v={90,70,0.0},c={1,1,1,1}}
	}
},
low=15,
high=150
]]
local graphTable = {graphs={},low=0,high=0}
local playerTable = {}
local teamTable = {}

local EzSVG = VFS.Include('luaui/Include/EzSVG.lua')

-- Stat information functions
local GetTeamList			= Spring.GetTeamList
local GetTeamStatsHistory	= Spring.GetTeamStatsHistory
local GetGaiaTeamId			= Spring.GetGaiaTeamID
local GetTeamInfo			= Spring.GetTeamInfo
local GetPlayerInfo			= Spring.GetPlayerInfo
local GetAllyTeamList		= Spring.GetAllyTeamList

local mergeAlliedTeams = false -- Whether or not to show all player graphs combined into one per allied team.

-- Turns numbers into smaller, more easily read versions. i.e. 12,000 = 12.0k.
-- The f is the number of decimals (for 3.14, n=1 would return '3.1' and n=0 would return '3')
local function ShortenNum(n)
	local f = 1

	if n > 1e10 then
		return string.format("%." .. f .. "fm", n / 1e9)
	elseif n > 1e4 then
		return string.format("%." .. f .. "fk", n / 1e3)
	else
		-- If the value is between 0.999 and -.999 but not equal to 0.0, we should see some decimals. Otherwise, don't show any.
		if (n >= 1) or (n == 0.0) or (n <= -1) then
			f = 0
		else
			f = 1
		end
		return string.format("%." .. f .. "f", n)
	end
end

local function ChangeGraphButtonPressed(_, key)
	if not isVisible then
		return
	end
	widget:ChangeGraph(key)
end

local function MergeAlliedPlayersButtonPressed()
	mergeAlliedTeams = not mergeAlliedTeams 
	dm.merge_allied_teams = mergeAlliedTeams 
	widget:ChangeGraph(lastSelectedGraphKey)

end

function widget:MouseEntered(_)
	graphIsHovered = true
end

function widget:MouseExited(_)
	graphIsHovered = false
end

local function GetAllyTeamListWithoutGaia()
	local retArray = {}
	for _, alliedTeamId in ipairs(GetAllyTeamList()) do
		local containsGaia = false
		for _, teamId in ipairs(GetTeamList(alliedTeamId)) do
			if teamId == GetGaiaTeamId() then
				containsGaia = true
			end
		end
		if not containsGaia then
			table.insert(retArray,alliedTeamId)
		end
	end
	
	return retArray
end

local function TogglePlayerPressed(_, teamId)
	playerTable[teamId+1].value = not playerTable[teamId+1].value 
	
	--dm["player_table"] = playerTable
	--dm:__SetDirty("player_table")
	
	widget:ChangeGraph(lastSelectedGraphKey)
end

local function ToggleTeamPressed(_, alliedTeamId)

	teamTable[alliedTeamId+1].value = not teamTable[alliedTeamId+1].value

	dm.team_table = teamTable

	widget:ChangeGraph(lastSelectedGraphKey)
end

local init_model = {
	toggle_player_pressed=TogglePlayerPressed,
	toggle_team_pressed=ToggleTeamPressed,
	change_graph_pressed = ChangeGraphButtonPressed,
	merge_allied_players_pressed = MergeAlliedPlayersButtonPressed,
	lowest_value = -1,
	highest_value = 1,
	display_value = 0,
	title_table = statButtons,
	player_table = playerTable,
	team_table = teamTable,
	time_end="0",
	last_graph_key="",
	merge_allied_teams=false, -- Whether or not to show all player graphs combined into one per allied team.
	merge_allied_teams_text="",
	team_text=""
}

local function inverse_lerp(a, b, value)
	-- Don't divide by 0. This can happen if b == a.
	if b - a == 0 then
		return 0.0
	end

    return (value - a) / (b - a)
end

local function lerp(a, b, t)
    return a + ((b - a) * t)
end

local function GetGraphY(lowestValue,highestValue,value)
	-- Y is the result of using the inverse lerp between the low/high values used as the weight in a lerp between the top and bottom of the graph.
	-- For example, if we have a value of 5, a low value of 0, and a high value of 10, we get .5 from an inverse lerp.
	-- Then, if we have a top of 50 and a bottom of 0, we get a y of 25.
	return lerp(graphHeight-graphMarginY,graphMarginY,inverse_lerp(lowestValue,highestValue,value))
end

local function RefreshTitles()
	
	statButtons = {
		{text = Spring.I18N('ui.gameGraph.metalUsed'), key= "metalUsed"},
		{text = Spring.I18N('ui.gameGraph.energyUsed'), key= "energyUsed"},
		{text = Spring.I18N('ui.gameGraph.metalProduced'), key = "metalProduced"},
		{text = Spring.I18N('ui.gameGraph.energyProduced'), key = "energyProduced"},
		{text = Spring.I18N('ui.gameGraph.metalExcess'), key = "metalExcess"},
		{text = Spring.I18N('ui.gameGraph.energyExcess'), key = "energyExcess"},
		{text = Spring.I18N('ui.gameGraph.metalReceived'), key = "metalReceived"},
		{text = Spring.I18N('ui.gameGraph.energyReceived'), key = "energyReceived"},
		{text = Spring.I18N('ui.gameGraph.metalSent'), key = "metalSent"},
		{text = Spring.I18N('ui.gameGraph.energySent'), key = "energySent"},
		{text = Spring.I18N('ui.gameGraph.metalStored'), key = "metalStored"},
		{text = Spring.I18N('ui.gameGraph.energyStored'), key = "energyStored"},
		{text = Spring.I18N('ui.gameGraph.activeUnits'), key = "activeUnits"},
		{text = Spring.I18N('ui.gameGraph.unitsKilled'), key = "unitsKilled"},
		{text = Spring.I18N('ui.gameGraph.unitsProduced'), key = "unitsProduced"},
		{text = Spring.I18N('ui.gameGraph.unitsDied'), key = "unitsDied"},
		{text = Spring.I18N('ui.gameGraph.unitsReceived'), key = "unitsReceived"},
		{text = Spring.I18N('ui.gameGraph.unitsSent'), key = "unitsSent"},
		{text = Spring.I18N('ui.gameGraph.unitsCaptured'), key = "unitsCaptured"},
		{text = Spring.I18N('ui.gameGraph.unitsStolen'), key = "unitsOutCaptured"},
		{text = Spring.I18N('ui.gameGraph.damageDealt'), key = "damageDealt"},
		{text = Spring.I18N('ui.gameGraph.damageReceived'), key = "damageReceived"},
	}
	
	-- The model doesn't have an up to date table yet. This sets it to be up to date.
	dm.title_table = statButtons
	dm.merge_allied_teams_text = Spring.I18N('ui.gameGraph.mergeAlliedTeams')
	dm.team_text = Spring.I18N('ui.gameGraph.team')
end



local function RefreshGraph()
    
	-- This sets the background to be transparent on the svg.
	EzSVG.setStyle("fill-opacity","0.0")
	local svg = EzSVG.Document(graphWidth, graphHeight, "rgb(0,0,0)")
	EzSVG.setStyle("fill-opacity","1.0")
	
	for _, graph in ipairs(graphTable.graphs) do 
		EzSVG.setStyle("stroke-width", "6")
		EzSVG.setStyle("stroke-linecap", "round")
		
		local color = graph[1].c
		local graph_line = EzSVG.Group()
		EzSVG.setStyle("stroke", EzSVG.rgb(color[1] * 255, color[2] * 255, color[3] * 255))
		-- We want to iterate on the graph, up to graph size - 1 so we can connect each vertice to the next one by a line.
		for i = 1, #graph-1 do
			local vertice = graph[i]
			local nextVertice = graph[i+1]
			-- Vertice.v[1] is x, while vertice.v[2] is y.
			graph_line:add(EzSVG.Line(vertice.v[1], vertice.v[2], nextVertice.v[1], nextVertice.v[2]))
		end
		EzSVG.clearStyle()
		svg:add(graph_line)
		
	end
	EzSVG.setStyle("stroke-width", "6")
	EzSVG.setStyle("stroke", "white")
	EzSVG.setStyle("stroke-dasharray","10,15")
	local zeroLine = EzSVG.Group()
	
	zeroLine:add(EzSVG.Line(0, GetGraphY(graphTable.low,graphTable.high,0), graphWidth, GetGraphY(graphTable.low,graphTable.high,0)))

	EzSVG.clearStyle()

	svg:add(zeroLine)
	
	document:GetElementById("graph-display"):SetAttribute("src", svg:tostr())

end

local function RefreshDecorators()
	local alpha = 255 * Spring.GetConfigFloat("ui_opacity", 0.7)
	
	local gradientBg = "decorator: repeating-linear-gradient(135deg, rgba(29, 29, 29, " .. alpha .. ") 0dp, rgba(29, 29, 29, " .. alpha .. ") 5dp, rgba(14, 14, 14, " .. alpha .. ") 5dp, rgba(14, 14, 14, " .. alpha .. ") 10dp);"
	document:GetElementById("rml-game-graph-panel"):SetAttribute("style",gradientBg)
	document:GetElementById("spacer"):SetAttribute("style",gradientBg)
	document:GetElementById("margin-2"):SetAttribute("style",gradientBg)

	document:GetElementById("spacer-2"):SetAttribute("style",gradientBg)
	document:GetElementById("time-list"):SetAttribute("style",gradientBg)
	




end

local function ShowDocument()
    if isVisible == true then
        return
    end
    isVisible = true

   
	
    RefreshTitles()
	
    document:ReloadStyleSheet()
	RefreshDecorators()
	widget:ChangeGraph(lastSelectedGraphKey)
    document:Show()
end

local function HideDocument()
    if isVisible == false then
        return
    end
    isVisible = false
	graphIsHovered = false
    if document then
        document:Hide()
    end
end

local function EvaluateMouse()
	if graphIsHovered then
		local _, mouseY = Spring.GetMouseState()
		local localMouseY = graph_absolute_y - mouseY

		-- Based on the local mouse position on the graph, calculate the value at that position, and display it.
		dm.display_value = ShortenNum(lerp(graphTable.low,graphTable.high,inverse_lerp(graphHeight-graphMarginY,graphMarginY,localMouseY)))
		-- Slide the display value by setting the height % of the already in place offset. Subtract 16 from the mouse position to get approximately the center of it.
		document:GetElementById("value-h-offset"):SetAttribute("style", "height:"..(((localMouseY-16)/graphHeight)*100).."%;")
		




		EzSVG.setStyle("fill-opacity","0.0")
		local svg = EzSVG.Document(graphWidth, graphHeight, "rgb(0,0,0)")
		local svgTwo = EzSVG.Document(graphWidth, graphHeight, "rgb(0,0,0)")
		EzSVG.setStyle("fill-opacity","1.0")
		local line = EzSVG.Group()
		EzSVG.setStyle("stroke", EzSVG.rgb(255,255,255))
		EzSVG.setStyle("stroke-width","2")
		
		line:add(EzSVG.Line(0, localMouseY, graphWidth, localMouseY))
		
		svg:add(line)
		
		
		
		EzSVG.setStyle("stroke-dasharray","5,5")
		EzSVG.setStyle("stroke", EzSVG.rgb(255,255,255))
		svgTwo:add(EzSVG.Line(0, localMouseY, graphWidth, localMouseY))
		
		document:GetElementById("graph-display-line-1"):SetAttribute("src", svg:tostr())
		document:GetElementById("graph-display-line-2"):SetAttribute("src", svgTwo:tostr())
		EzSVG.clearStyle()
	else
		document:GetElementById("graph-display-line-1"):SetAttribute("src", "")
		document:GetElementById("graph-display-line-2"):SetAttribute("src", "")
		dm.display_value = ''
	end
	
end



function widget:Update(dt)
	if not isVisible then
		return
	end
	EvaluateMouse()
end

function widget:GameFrame(f,forceUpdate)
	if not isVisible then
		return
	end
	
	
	
	

	if f % 30 ~= 0 then
		return
	end
	
	RefreshGraph()
end

function widget:DrawScreen()
	if not isVisible then
		return
	end
	--[[gl.Color(.2,.2,.2,1)
	gl.Rect(graph_absolute_x, graph_absolute_y-graphHeight, graph_absolute_x+graphWidth, graph_absolute_y)
	--gl.Shape(GL.TRIANGLE_STRIP_ADJACENCY, {{v={graph_absolute_x,graph_absolute_y-graphHeight,0.0}},v={graph_absolute_x,graph_absolute_y,0.0},{v={graph_absolute_x+graphWidth,graph_absolute_y,0.0}}})
	gl.Color(0,0,1,1)
	gl.LineStipple(false)
	gl.LineWidth(5.0)
	gl.Shape(GL.LINE_STRIP, {{v={graph_absolute_x,graph_absolute_y-graphHeight,0.0}},{v={graph_absolute_x+graphWidth,graph_absolute_y,0.0},c={1.0,1.0,0,1.0}}})]]
end

local function RefreshGraphHolderUI()
	graph_holder = document:GetElementById("graph-display")
	local _, screen_y = Spring.GetScreenGeometry()
	graph_absolute_y = screen_y-graph_holder.absolute_top
	--graph_absolute_x = graph_holder.absolute_left
	graphHeight = graph_holder.client_height
	graphWidth = graph_holder.client_width
	
end

function widget:ViewResize()
	RefreshGraphHolderUI()
end

function widget:Initialize()
    widget.rmlContext = RmlUi.GetContext("shared")

    

    dm = widget.rmlContext:OpenDataModel(main_model_name, init_model)
	
    if not dm then
        Spring.Echo("RmlUi: Failed to open data model ", main_model_name)
        return
    end

    document = widget.rmlContext:LoadDocument("luaui/rmlwidgets/gui_game_graph/gui_game_graph.rml", widget)
    if not document then
        Spring.Echo("RmlUi: Failed to load game graph document")
        return
    end

	WG['gameGraph'] = {}
	WG['gameGraph'].toggle = function(state)
		widget:Toggle(state)
	end
	WG['gameGraph'].isvisible = function()
		return isVisible
	end

	RefreshGraphHolderUI()
	
    -- uncomment the line below to enable debugger
	-- RmlUi.SetDebugContext('shared')

	RefreshDecorators()

	
	widget:ChangeGraph("metalUsed")
end

function widget:Toggle(state)
	if state ~= nil then
		if state == false then
			HideDocument()
		else
			ShowDocument()
		end
	else
		if isVisible then
			HideDocument()
		else
			ShowDocument()
		end
	end
end

function widget:Shutdown()
    widget.rmlContext:RemoveDataModel(main_model_name)
    document:Close()
end

-- This function is only for dev experience, ideally it would be a hot reload, and not required at all in a completed widget.
function widget:Reload(event)
    Spring.Echo("Reloading")
	if event ~= nil then
    	Spring.Echo(event)
	end
    widget:Shutdown()
    widget:Initialize()
	isVisible = false
	ShowDocument()
end

function widget:GameOver()
    RefreshGraph()
end


function widget:LanguageChanged()
	RefreshTitles()
end

local function CreateGraphVertsArray(statData,lowestValue,highestValue,colorArray,time_end,time_start)
	local verts = {}
	
	for _, entry in ipairs(statData) do
		local value = entry.value
		local y = GetGraphY(lowestValue,highestValue,value)
		-- X is the result of using the inverse lerp between the start and end time used as a weight in a lerp between the left and right of the graph.
		local x = lerp(graphWidth-graphMarginX,graphMarginX,inverse_lerp(time_end,time_start,entry.time))
		table.insert(verts,{v={x,y,0.0},c=colorArray})
	end
	
	return verts
end

local function GetStatData(statName, teamId)
	local retTable = {}
	local range = GetTeamStatsHistory(teamId)
	if not range then
		return nil, -1, -1
	end
	local history = GetTeamStatsHistory(teamId,1,range)
	
	-- The current lowest and highest values. We will use these for the graph y value.
	local lowestValue = 0
	local highestValue = 0
	
	
	if not history then
		return nil, -1, -1
	end
	
	-- We want to condense the table data only into the entries that are relevant to the statName.
	
	for _, entry in ipairs(history) do
		local value
		if statName == "activeUnits" then
			-- We have to construct this from the existing data. 
			-- Active units = units produced + units received  + united captured - units died - units sent - units outcaptured(stolen)
			value = (entry.unitsProduced + entry.unitsReceived + entry.unitsCaptured) - (entry.unitsDied + entry.unitsSent + entry.unitsOutCaptured)
		elseif statName == "metalStored" then
			value = (-(entry.metalExcess + entry.metalSent + entry.metalUsed)) + (entry.metalProduced + entry.metalReceived)  + 1000 -- players start with 1000 at the start
			
		elseif statName == "energyStored" then
			value = (-(entry.energyExcess + entry.energySent + entry.energyUsed)) + (entry.energyProduced + entry.energyReceived) + 1000 -- players start with 1000 at the start
		else
			value = entry[statName]
		end
		
		
		

		if value < lowestValue then
			lowestValue = value
		elseif value > highestValue then
			highestValue = value
		end
		
		table.insert(retTable, {value = value, time = entry.time})
	end
	
		
	

	return retTable, lowestValue, highestValue

end

-- For each team id in the array, add their values together.
local function GetCombinedStatData(statName,teamsArray)
	local retArray = {}
	local lowestValue = 0
	local highestValue = 0
	for _, teamId in ipairs(teamsArray) do
		if teamId ~= GetGaiaTeamId then
			local statData = GetStatData(statName,teamId)
			
			if statData then
				for index, entry in ipairs(statData) do
					if retArray[index] == nil then
						retArray[index] = entry
					else
						retArray[index].value = retArray[index].value + entry.value
					end
				end
			end
		end
	end

	for _, entry in ipairs(retArray) do
		if entry.value < lowestValue then
			lowestValue = entry.value
		elseif entry.value > highestValue then
			highestValue = entry.value
		end
	end
	
	return retArray, lowestValue, highestValue
end

local function GetAverageTeamColor(allyTeamId)
	local teamList = GetTeamList(allyTeamId)
	local teamColor = {0,0,0,1}
	for _, teamId in ipairs(teamList) do
		local r,g,b,_ = Spring.GetTeamColor(teamId)
		teamColor[1] = teamColor[1] + r/#teamList
		teamColor[2] = teamColor[2] + g/#teamList
		teamColor[3] = teamColor[3] + b/#teamList
	end
	return teamColor
end

local function Compare(a,b)
	return a.sort_var < b.sort_var

end

function widget:ChangeGraph(key)
	if not isVisible then
		return
	end
	
	local range = GetTeamStatsHistory(0)
	
	local history = GetTeamStatsHistory(0,range)
	
	if not history then
		Spring.Echo("No history data available!")
		return
	end

	if #history == 0 then
		return
	end
	
	lastSelectedGraphKey = key
	dm.last_graph_key = key

	local time_end = history[#history].time
	
	local seconds = time_end%60.0
	if seconds > 10 then
		dm.time_end = string.format("%.0f:%.0f",math.floor(time_end/60.0),seconds)
	else
		dm.time_end = string.format("%.0f:0%.0f",math.floor(time_end/60.0),seconds)
	end
	local time_start = 0
	
	-- Out of all the teams, we need to get the true highest and true lowest values.
	local lowestValue = 0
	local highestValue = 0

	for teamIndex,allyTeamId in ipairs(GetAllyTeamListWithoutGaia()) do
		if not mergeAlliedTeams then 
			for index, teamId in ipairs(GetTeamList(allyTeamId)) do
				if teamId ~= GetGaiaTeamId() and teamId then
					local history, low, high = GetStatData(key, teamId)
					-- Fill the player table. We have to use the index + 1 because lua tables start at 1, not 0. Otherwise the data model handler won't recognize it and will refuse to render it.
					if playerTable[teamId+1] == nil then
						local _,leader = GetTeamInfo(teamId,false)
						local playerName = GetPlayerInfo(leader,true)
						if Spring.GetGameRulesParam('ainame_'..teamId) then
							playerName = Spring.GetGameRulesParam('ainame_'..teamId).." (AI)"
						end
						local r,g,b,a = Spring.GetTeamColor(teamId)
						playerTable[teamId+1] = {value=true,
												player_color=string.format("rgba(%f,%f,%f,%f)",r*255,g*255,b*255,a*255),
												player_name=playerName,
												has_history = (history~=nil),
												has_spacer = (index == 1), -- Add a spacer between the teams so it's easier to see which players are on which team.
												team_index = teamIndex,
												sort_var = teamIndex* 64 + index,
												team_id = teamId
												}
					end

					-- Entries can have a value of false if the player toggled that team in the UI.
					
					
					if playerTable[teamId+1].value == true and playerTable[teamId+1].has_history == true then
						if history then
							if low < lowestValue then
								lowestValue = low
							end
							if high > highestValue then
								highestValue = high
							end
						end
					end
				end
			end
		else
			local history, low, high = GetCombinedStatData(key, GetTeamList(allyTeamId))
			if teamTable[allyTeamId+1] == nil then
				local color = GetAverageTeamColor(allyTeamId)
				teamTable[allyTeamId+1] = {value=true,
										team_color=string.format("rgba(%f,%f,%f,%f)",color[1]*255,color[2]*255,color[3]*255,color[4]*255),
										team_name="Team "..(allyTeamId+1),
										has_history = (history~=nil),
										}
			end

			if teamTable[allyTeamId+1].value == true and teamTable[allyTeamId+1].has_history == true then
						if history then
							if low < lowestValue then
								lowestValue = low
							end
							if high > highestValue then
								highestValue = high
							end
						end
					end
		end
	end

	local graphs = {}
	-- If the low and high values are both equal, this'll add one to em which'll make the zero line end up in the middle so the graph doesn't look broken.
	if lowestValue == highestValue then
		lowestValue = lowestValue - 1
		highestValue = highestValue + 1
	end

	
	if not mergeAlliedTeams then
		for _, teamId in ipairs(GetTeamList()) do
			if teamId ~= GetGaiaTeamId() then
				if playerTable[teamId+1].value == true then
					local condensedHistory, _, _ = GetStatData(key, teamId)
					local verts = {}
					if condensedHistory then
						local r,g,b,a = Spring.GetTeamColor(teamId)
						verts = CreateGraphVertsArray(condensedHistory,lowestValue,highestValue,{r,g,b,a},time_end,time_start)
						
						table.insert(graphs,verts)
					end
				end
			end
		end
	else
		for _,allyTeamId in ipairs(GetAllyTeamListWithoutGaia()) do
			if teamTable[allyTeamId+1].value == true then
				local teamColor = GetAverageTeamColor(allyTeamId)
				
				local mergedStats, _, _ = GetCombinedStatData(key,GetTeamList(allyTeamId))
				
				local verts = {}
				if mergedStats then
					verts = CreateGraphVertsArray(mergedStats,lowestValue,highestValue,teamColor,time_end,time_start)

					table.insert(graphs,verts)
				end
			end
		end
	end
	
	
	
	graphTable = {graphs=graphs,low=lowestValue,high=highestValue}
	
	-- Have to use a sorted copy here or if the teams aren't in a neat order (which they'll almost never be) the player ordering will be incorrect.
	local sorted_playerTable = table.copy(playerTable)
	table.sort(sorted_playerTable,Compare)
	dm.player_table = sorted_playerTable
	dm.team_table = teamTable
	
	dm.lowest_value = ShortenNum(lowestValue)
	
	dm.highest_value = ShortenNum(highestValue)
	
	

	RefreshGraph()
end

function widget:Close()
	if not isVisible then
		return
	end
	HideDocument()
end

-- Hides the widget when the lobby is enabled.
function widget:RecvLuaMsg(msg, playerID)
	if not isVisible then
		return
	end
    if msg:sub(1, 19) == 'LobbyOverlayActive0' then
		if isVisible then
        	document:Show()
		end
    elseif msg:sub(1, 19) == 'LobbyOverlayActive1' then
        document:Hide()
    end
end