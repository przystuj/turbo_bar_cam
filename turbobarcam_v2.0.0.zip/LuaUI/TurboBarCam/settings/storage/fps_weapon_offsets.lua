return {
  ["armepoch"] = {
    ["FORWARD"] = 0,
    ["HEIGHT"] = 0,
    ["ROTATION"] = 0,
    ["SIDE"] = 0,
  },
}