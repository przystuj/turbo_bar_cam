return {
  ["orbit"] = {
    ["DISTANCE"] = 880,
    ["HEIGHT"] = 1200,
    ["SPEED"] = 0.05,
  },
}